package fernanda.itics.tesoem.edu.examen;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class Pantalla3 extends AppCompatActivity {

    TextView button2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pantalla3);

        Bundle parametros = this.getIntent().getExtras();

        button2 = (TextView) findViewById(R.id.bienvenida);
        button2.setText("Bienvenida " +parametros.getString("Nombre").toString());
    }
}