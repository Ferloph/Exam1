package fernanda.itics.tesoem.edu.examen;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class Pantalla4 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pantalla4);
    }
        public void llamarbtn(View v){
            Intent cargar = new Intent(this, Pantalla5.class);
            startActivity(cargar);
        }
    public void llamarbtn2(View v){
        Intent cargar = new Intent(this, Pantalla6.class);
        startActivity(cargar);

    }
    public void llamarbtn3(View v){
        Intent cargar = new Intent(this, Pantalla7.class);
        startActivity(cargar);
    }
    public void llamarbtn4(View v){
        System.exit(0);
    }
    public void llamarbtn5(View v){
        Intent cargar = new Intent(this, Pantalla8.class);
        startActivity(cargar);

    }
  }