package fernanda.itics.tesoem.edu.examen;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class Pantalla7 extends AppCompatActivity {


    EditText num1;
    TextView resultado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pantalla7);

        num1 = (EditText) findViewById(R.id.txtnum1);
        resultado = (TextView) findViewById(R.id.lblresultado);

    }

    public void calculaPotencia(View v){
        int a,r;
        a = Integer.parseInt(num1.getText().toString());

        r = a*a;
        resultado.setText(String.valueOf(r));
    }
}