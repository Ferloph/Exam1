package fernanda.itics.tesoem.edu.examen;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import static fernanda.itics.tesoem.edu.examen.R.layout.activity_main;
import static fernanda.itics.tesoem.edu.examen.R.layout.activity_pantalla2;

public class pantalla2 extends AppCompatActivity implements View.OnClickListener{

    Button button2;
    EditText TextN;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pantalla2);

    button2  = (Button) findViewById(R.id.button1);

         button2.setOnClickListener(this);


        TextN= (EditText) findViewById(R.id.TextN);

    }
    @Override

    public void onClick(View v) {
        Toast.makeText(this, "Bienvenido a tu programa de operaciones", Toast.LENGTH_LONG).show();
        button2.setEnabled(true);
    }


    public void llamarpantalla(View v){
        Intent llamar = new Intent(this, Pantalla3.class);
        llamar.putExtra("Nombre", TextN.getText().toString());
        startActivity(llamar);

    }
public void llamarbutton(View v){
        Intent cargar = new Intent(this,Pantalla4.class);
        startActivity(cargar);
}

}
